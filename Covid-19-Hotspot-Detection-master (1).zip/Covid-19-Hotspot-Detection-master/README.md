# Covid-19-Hotspot-Detection
Covid 19 hotspot detection using DBSCAN Algorithm.
